package com.example.tarranza.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.tarranza.FoodItems;
import java.util.ArrayList;
import java.util.List;

public class FoodViewModel extends ViewModel {
    private final MutableLiveData<List<FoodItems>> foods = new MutableLiveData<>();
    public LiveData<List<FoodItems>> getFoods() { return foods; }

    public void loadFoods() {
        List<FoodItems> foodList = new ArrayList<>();
        foodList.add(new FoodItems("Meat", "The classic food.", 100.9));
        foodList.add(new FoodItems("Chicken", "Crispy fried chicken.", 60.50));
        foodList.add(new FoodItems("Fish", "Eat all you can sa Island.", 120));
        foods.setValue(foodList);
    }
}
